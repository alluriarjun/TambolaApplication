package tambola.model;

public enum ClaimType {
    TOP_ROW, MIDDLE_ROW, BOTTOM_ROW, FULL_HOUSE, EARLY_FIVE
}